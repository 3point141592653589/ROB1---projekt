import numpy as np

#from ctu_crs import CRS93
from ctu_crs import CRS97




def move_ik(robot, pos_goal,keep_rot = False):

    q_rad = []
    
        
    rot = np.eye(4)
    for i in range(4):
        rz = -np.pi*i/2
        rot [0,0] = np.cos(rz)
        rot [1,1] = rot [0,0]
        rot [0,1] = np.sin(rz)
        rot [1,0] = -rot [0,1]
        actual = pos_goal @ rot
        q_rad = q_rad + robot.ik(actual)


    #'''

    q_radlim = np.array([q for q in q_rad if robot.in_limits(q)])
    if not len(q_radlim):
        print("pose not reachable")
        return
    #'''

      
    robot_q = robot.get_q()
    q_radlim[:,5] *= -1
    q = min(q_radlim, key=lambda x: np.linalg.norm(robot_q - x))


    robot.move_to_q (q)
    robot.wait_for_motion_stop()

