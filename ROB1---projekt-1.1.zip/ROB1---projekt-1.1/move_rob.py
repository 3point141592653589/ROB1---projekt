import numpy as np

#from ctu_crs import CRS93
from ctu_crs import CRS97




def move_ik(robot, pos_goal):
    q_rad = robot.ik(pos_goal)
    
    #'''
    q_radlim = [q for q in q_rad if robot.in_limits(q)]
    if not q_radlim:
        print("pose not reachable")
        return
    #'''

    robot_q = robot.get_q()
    q = min(q_rad, key=lambda x: np.linalg.norm(robot_q - x))
    q [5] = q[5]-np.pi
    robot.move_to_q (q)
    robot.wait_for_motion_stop()


if __name__ == "__main__":

    robot = CRS97 (tty_dev="/dev/mars" )

    robot.initialize( home=False )
    poz = np.array([[-1, 0, 0, 0.5],[0,1,0,0],[0,0,-1,0.35],[0,0,0,1]])

    move_ik(robot, poz)
    poz [1,3] = 0.2
    move_ik(robot, poz)