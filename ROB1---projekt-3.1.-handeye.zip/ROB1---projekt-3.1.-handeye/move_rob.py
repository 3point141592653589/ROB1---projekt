import numpy as np

#from ctu_crs import CRS93
#from ctu_crs import CRS97




def move_ik(robot, pos_goal,keep_rot = False):

    q_rad = []
    
        
    rot = np.eye(4)
    for i in range(4):
        rz = -np.pi*i/2
        rot [0,0] = np.cos(rz)
        rot [1,1] = rot [0,0]
        rot [0,1] = np.sin(rz)
        rot [1,0] = -rot [0,1]
        actual = pos_goal @ rot
        '''
        if keep_rot:
            robot_poz = robot.fk(robot.get_q())
            matrix = robot_poz[:3,:3]-actual[:3,:3]>1
            if any(any(row) for row in matrix):
                continue
        #actual [:2,:2] = actual [:2,:2] + rot
        #'''
        q_rad = q_rad + robot.ik(actual)




    #q_rad = robot.ik(pos_goal)
    #'''

    q_radlim = [q for q in q_rad if robot.in_limits(q)]
    if not q_radlim:
        print("pose not reachable")
        return
    #'''

      
    robot_q = robot.get_q()

    q = min(q_radlim, key=lambda x: np.linalg.norm(robot_q - x))

    if np.abs(q[5]-robot_q[5])>3:
        if q[5]<0:
            q[5] = q[5] + np.pi
        else:
            q[5] = q[5] - np.pi

    '''
    dis = max (np.abs(robot_q - q))
    if dis >2:
        reorient = robot.ik(robot.fk(robot_q))
        reorientlim = [q for q in reorient if robot.in_limits(q)]
        move  = min(reorientlim, key=lambda x: np.linalg.norm(q - x))
        move[5] = -move[5]
        robot.move_to_q (move)
        robot.wait_for_motion_stop()
    #'''

    q[5] = -q[5]
    robot.move_to_q (q)
    robot.wait_for_motion_stop()

