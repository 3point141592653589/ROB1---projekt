


import numpy as np
import cv2 as cv
import time

import util



from transformation import target_to_base
from move_rob import move_ik as move
#from move_viz import plot_transform as move

from ctu_crs import CRS93
from ctu_crs import CRS97


import matplotlib.pyplot as plt



def grab_cube(robot, targ_to_base, cube, gripper):
    poz = np.eye(4)

    poz[0, 3] = cube[0]/1000-0.0005
    poz[1, 3] = cube[1]/1000-0.006
    poz[1, 3] *= 1.09
    poz[2,3] = -0.18
    move(robot,targ_to_base @ poz)
    poz[2,3] = -0.08
    move(robot,targ_to_base @ poz)
    #'''


    poz[2,3] = -0.04
    move(robot, targ_to_base @ poz)
    if robot is not None:
        robot.gripper.control_position(gripper)
        time.sleep(1.5)
    poz[2,3] = -0.08
    move(robot,targ_to_base @ poz)
    poz[2,3] = -0.18
    move(robot, targ_to_base @ poz)
    #'''
    return



robot = None

#robot = CRS93 (tty_dev="/dev/mars" )
robot = CRS97 (tty_dev="/dev/mars" )


robot.initialize( home=False )
#robot.initialize( )

#'''
if robot is not None:
    robot.gripper.control_position(600)
    robot.soft_home ( )
    q = robot.get_q ( )
    q [0] += np.pi/8
    robot.move_to_q (q)
    robot.wait_for_motion_stop ( )
#'''

#image = cv.imread("aruco\Image__2024-12-26__13-25-35.bmp")
#'''
camera = util.init_camera()
image = camera.grab_image()
#'''


#'''
cam_to_base = np.load("handeye_output/cam2base.npy")
if robot is not None:
    robot.dh_offset = np.load("handeye_output/dh_offset.npy")
#'''
'''
cam_to_base = np.eye(4)
cam_to_base [:3,3] = [0.445,0.015,1.353]
#'''


if cam_to_base is None:
    print("No cam2base data")
    exit(1)




detector = cv.aruco.ArucoDetector(
        cv.aruco.getPredefinedDictionary(cv.aruco.DICT_4X4_50),
    )

corners, ids, rejected = detector.detectMarkers(image)
if ids is None:
    print("No markers detected")
    exit(1)
ids = np.array(ids)
ids = ids[:,0]



if not (len(ids) == 4):
    print("wrong number of markers detected")
    exit(1)
sorted_ids = np.sort(ids)

while True:
    print("Choose bloks source desk: 0:(IDs:",sorted_ids[0],",",sorted_ids[1],"),1:(IDs:",sorted_ids[2],",",sorted_ids[3],")")
    num_input = input()
    if num_input.isdigit():
        direction = int(num_input)
        break
    else:
        print("It's not a number")
if direction:
    direction = 1


targ1_to_base = target_to_base(sorted_ids[2*direction],image)
if targ1_to_base is None:
    print("No target detected")
    exit(1)

targ2_to_base = target_to_base(sorted_ids[2*(1-direction)],image)
if targ2_to_base is None:
    print("No target detected")
    exit(1)

#print(targ1_to_base)
#print(targ2_to_base)




if robot is None:
    move(robot, targ1_to_base,color='r')

i = sorted_ids[0]
j = i+1
name = f"desky/positions_plate_0{i}-0{j}.csv"
data1 = np.loadtxt(name, delimiter=',', skiprows=1)

i = sorted_ids[2]
j = i+1
name = f"desky/positions_plate_0{i}-0{j}.csv"
data2 = np.loadtxt(name, delimiter=',', skiprows=1)

if direction:
    temp = data1
    data1 = data2
    data2 = temp

midpoint = np.eye(4)
midpoint[:3,3] = [0.5,0,0.3]
midpoint[2,2] = -1


for i in range(len(data1)):
    if i:
        q = robot.get_q ( )
        q [0] += np.pi/6
        robot.move_to_q (q)
        robot.wait_for_motion_stop ( )
        image = camera.grab_image()
        targ1_to_base = target_to_base(sorted_ids[2*direction],image)
        targ2_to_base = target_to_base(sorted_ids[2*(1-direction)],image)
    grab_cube(robot, targ1_to_base, data1[i], -800)
    move(robot,midpoint)
    grab_cube(robot, targ2_to_base, data2[i], 600)
    move(robot,midpoint)




if robot is not None:
    robot.soft_home ( )
    robot.release ( )
    robot.close ( )

else:
    plt.show()






