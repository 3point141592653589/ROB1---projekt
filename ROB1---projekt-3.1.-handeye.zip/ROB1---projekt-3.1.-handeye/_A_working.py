

import numpy as np
import cv2 as cv
import time

import util

#from util import move_ik
from targrt_to_cam import target_to_cam
from move_rob import move_ik as move
#from move_viz import plot_transform as move

from ctu_crs import CRS93
from ctu_crs import CRS97


import matplotlib.pyplot as plt


def grab_cube(robot, targ_to_base, cube, gripper):
    poz = np.eye(4)

    poz[0, 3] = cube[0]/1000
    poz[1, 3] = cube[1]/1000
    poz[2,3] = 0
    move(robot,targ_to_base @ poz)
    
    '''
    if (targ_to_base @ poz)[0,3]<0.4:
        poz[2,3] = 0.08
        move(robot, targ_to_base @ poz)#,keep_rot=True)    
    #'''

    poz[2,3] = 0.12
    move(robot, targ_to_base @ poz)#,keep_rot=True)
    if robot is not None:
        robot.gripper.control_position(gripper)
        time.sleep(1)
    poz[2,3] = 0
    move(robot, targ_to_base @ poz)#, keep_rot=True)
    #'''
    return



robot = None

robot = CRS93 (tty_dev="/dev/mars" )
#robot = CRS97 (tty_dev="/dev/mars" )

robot.initialize( home=False )
#robot.initialize( )

#'''
if robot is not None:
    robot.gripper.control_position(400)
    robot.soft_home ( )
    q = robot.get_q ( )
    q [1] = q[1]+np.pi/8
    robot.move_to_q (q)
    robot.wait_for_motion_stop ( )
#'''

#image = cv.imread("aruco\Image__2024-12-26__13-28-20.bmp")
#'''
camera = util.init_camera()
image = camera.grab_image()
#'''


#'''
cam_to_base = np.load("handeye_output/cam2base.npy")

#cam_to_base = np.linalg.inv(cam_to_base)
if robot is not None:
    robot.dh_offset = np.load("handeye_output/dh_offset.npy")
#'''



'''
cam_to_base = np.eye(4)
cam_to_base [:3,3] = [0.445,0.015,1.35]
#'''
if cam_to_base is None:
    print("No cam2base data")
    exit(1)



detector = cv.aruco.ArucoDetector(
        cv.aruco.getPredefinedDictionary(cv.aruco.DICT_4X4_50),
    )

corners, ids, rejected = detector.detectMarkers(image)
if ids is None:
    print("No markers detected")
    exit(1)
min_id = min(ids)
targ_to_cam = target_to_cam(int(min_id[0]),image)

if targ_to_cam is None:
    print("No target detected")
    exit(1)

#'''
rot = np.eye(4)
rot [0,0] = -1
rot [2,2] = -1
cam_to_base = cam_to_base @ rot

rot = np.eye(4)
rot [:2,:2] = [[0,-1],[1,0]]
cam_to_base = cam_to_base @ rot

rot = np.eye(4)
rot [2,3] = 0.16
#rot [1,3] = 0.007
cam_to_base = cam_to_base @ rot
#cam_to_base[:2,2] = -cam_to_base[:2,2]
#cam_to_base[3,:] = -cam_to_base[3,:]
#'''



'''
#rx = np.atan2(targ_to_cam[2,1],targ_to_cam[2,2])
#ry = np.asin(-targ_to_cam[2,0])
rz = -np.atan2(targ_to_cam[1,0],targ_to_cam[0,0])
rot = np.cos(rz) * np.eye(3)
rot[2,2] = -1
rot [0,1] = np.sin(rz)
rot [1,0] = -rot [0,1]
targ_to_cam [:3,:3] = rot
#'''
'''
rx = np.atan2(targ_to_cam[2,1],targ_to_cam[2,2])
rot = np.cos(rx) * np.eye(3)
rot[0,0]=1
rot [1,2] = np.sin(rx)
rot [2,1] = -rot [1,2]
targ_to_cam [:3,:3] = rot

ry = np.asin(-targ_to_cam[2,0])
rot = eye(3)
rot [0,0] = np.cos(ry)
rot [2,2] = rot [0,0]
rot [0,2] = np.sin(ry)
rot [2,0] = -rot [0,2]
#'''

rot = np.eye (4)
#rot [0,0] = -1
rot [2,2] = -1

targ_to_cam = targ_to_cam @ rot


targ_to_base = cam_to_base @ targ_to_cam
#targ_to_base = np.linalg.inv(targ_to_base)
#print(targ_to_base-np.dot(cam_to_base, targ_to_cam))
print(targ_to_base)

'''
cam_to_base = np.linalg.inv(cam_to_base)
targ_to_base = np.dot(cam_to_base, targ_to_cam)
#targ_to_base = np.linalg.inv(targ_to_base)
'''

if robot is None:
    move(robot, targ_to_base,color='r')

i = int(min_id[0])
j = i+1
name = f"desky/positions_plate_0{i}-0{j}.csv"
data = np.loadtxt(name, delimiter=',', skiprows=1)

#data = [data[-1]]

for cube in data:
    grab_cube(robot, targ_to_base, cube, -800)

    #'''
    if robot is not None:
        q = robot.get_q ( )
        q [0] = q[0]+np.pi/6
        robot.move_to_q (q)
        robot.wait_for_motion_stop ( )
        robot.gripper.control_position(800)
        time.sleep(1)
    #'''

if robot is not None:
    robot.soft_home ( )
    q = robot.get_q ( )
    q [1] = q[1]+np.pi/8
    robot.move_to_q (q)
    robot.wait_for_motion_stop ( )
    robot.release ( )
    robot.close ( )

else:
    plt.show()






