from pathlib import Path

import cv2 as cv
import numpy as np

from aruco_relative_pose import get_camera_pose


# Our Basler camera interface
from basler_camera import BaslerCamera


def homo_to_R_t(C, inv=False):
    R = C[:3, :3]
    t = C[:3, 3]
    if inv:
        R = R.T
        t = -R @ t
    return R, t


def target_to_cam(aru_id,image):
    K = np.load("cam_calib/cam_params/K.npy")
    dist = np.load("cam_calib/cam_params/dist.npy")
    #cam2base = np.load("handeye_output/cam2base.npy")


    if image is None:
        return None
    target2cam = get_camera_pose(
        image,
        {aru_id: ((0,0), 0.036), aru_id+1: ((0.18,0.14), 0.036)},
        K,
        dist,
        #method=cv.SOLVEPNP_IPPE_SQUARE,
    )
    
    return  target2cam

def target_to_base(aru_id,image):
    cam_to_base = np.load("handeye_output/cam2base.npy")
    if cam_to_base is None:
        print("No cam2base data")
        exit(1)

    targ_to_cam = target_to_cam(aru_id,image)
    if targ_to_cam is None:
        print("No target detected")
        exit(1)
    targ_to_base = cam_to_base @ targ_to_cam

    #'''
    angles = [0,0,0]
    angles[0] = np.atan2(targ_to_base[2,1],targ_to_base[2,2])
    angles[1] = np.atan2(-targ_to_base[2,0],np.sqrt(targ_to_base[2,1]**2+targ_to_base[2,2]**2))
    angles[2] = np.atan2(targ_to_base[1,0],targ_to_base[0,0])
    #'''

    #'''
    for i in range(2):
        if angles[i] > np.radians(12):
            angles[i] = np.radians(15)
        elif angles[i] < -np.radians(12):
            angles[i] = -np.radians(15)
        elif angles[i] > np.radians(3):
            angles[i] = np.radians(7)
        elif angles[i] < -np.radians(3):
            angles[i] = -np.radians(7)
        else:
            angles[i] = 0


    cosx = np.cos(angles[0])
    sinx = np.sin(angles[0])
    cosy = np.cos(angles[1])
    siny = np.sin(angles[1])
    cosz = np.cos(angles[2])
    sinz = np.sin(angles[2])


    rotx = np.eye(3)*cosx
    rotx[0,0] = 1
    rotx[1,2] = -sinx
    rotx[2,1] = sinx

    roty = np.eye(3)*cosy
    roty[1,1] = 1
    roty[0,2] = siny
    roty[2,0] = -siny

    rotz = np.eye(3)*cosz
    rotz[2,2] = 1
    rotz[0,1] = -sinz
    rotz[1,0] = sinz

    rot = rotz @ roty @ rotx
    targ_to_base[:3,:3] = rot
    #'''

    return targ_to_base



def scan_picture():
# take picture with camera

    camera: BaslerCamera = BaslerCamera()
 
    # Camera can be connected based on its' IP or name:
    # Camera for robot CRS 93
    #   camera.connect_by_ip("192.168.137.107")
    #   camera.connect_by_name("camera-crs93")
    # Camera for robot CRS 97
    #   camera.connect_by_ip("192.168.137.106")
    #   camera.connect_by_name("camera-crs97")
    camera.connect_by_name("camera-crs97")
 
    # Open the communication with the camera
    camera.open()
    # Set capturing parameters from the camera object.
    # The default parameters (set by constructor) are OK.
    # When starting the params should be send into the camera.
    camera.set_parameters()
    # Starts capturing images by camera.
    # If it is not done, the grab_image method starts it itself.
    camera.start()
 
    # Take one image from the camera
    img = camera.grab_image()
    # If the returned image has zero size,
    # the image was not captured in time.
    if (img is not None) and (img.size > 0):
        # Show the image in OpenCV
        cv.namedWindow('Camera image', cv.WINDOW_NORMAL)
        cv.imshow('Camera image', img)
        #cv2.waitKey(0) ## no waiting
    else:
        print("The image was not captured.")
 
    # Close communication with the camera before finish.
    camera.close()
    return img



if __name__ == "__main__":
    
    image = cv.imread("aruco/Image__2024-12-26__13-25-35.bmp")
    #image = scan_picture()
    print(target_to_base(1,image))

