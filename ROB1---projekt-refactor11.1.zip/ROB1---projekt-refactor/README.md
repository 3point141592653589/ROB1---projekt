link na data:

https://drive.google.com/drive/folders/1_iKQy44mIW2S7ehKuhvqniLMdQ2tmGRX?usp=sharing
