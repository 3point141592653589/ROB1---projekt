import numpy as np
from ctu_crs import CRS97
robot = CRS97()
from hardware_control.robot.rotations import euler2mat
from hardware_control.robot.move import move_closest_ik

robot.reset_motors()
robot.initialize(home=False)
#robot.initialize()
robot.gripper.control_position(750)
robot.soft_home ( )


#q_rad = robot.get_q( )
#q_rad[0] = q_rad[0]+np.pi/3
#robot.move_to_q (q_rad)
#robot.release()




#robot.gripper.control_position(500)
# poz = np.array([[0, 0, 1, 0.7],[0,1,0,0],[-1,0,0,0.5],[0,0,0,1]])
#poz = np.array([[0, 0, 1, 0.7],[1,0,0,0],[0,1,0,0.5],[0,0,0,1]]) #kolem x

#deska grip
#poz = np.array([[-1, 0, 0, 0.36],[0,1,0,-0.2],[0,0,-1,0.235],[0,0,0,1]])

# poz = np.array([[-1, 0, 0, 0.34],[0,1,0,0],[0,0,-1,0.235],[0,0,0,1]])

#deska lift
#poz = np.array([[-1, 0, 0, 0.5],[0,1,0,0],[0,0,-1,0.35],[0,0,0,1]])

#deska flip
#poz = np.array([[0,1,0,0.5], [-1,0,0,0.3], [0,0,1,0.35]])

#poz = robot.fk(np.radians([0,0,0,0,0,0]))

#poz = robot.fk(robot.get_q())
#poz[3, 0] += 0.01

print(robot.fk(robot.get_q()))

poz = euler2mat([(np.pi, "x"), (-np.pi/2, "z")])
poz[:3, 3] = np.array([0.4, 0, 0.2])

#move_closest_ik(robot, poz)

q_rad = robot.get_q( )

q_deg = np.rad2deg(q_rad)
print("Position␣[deg]:" , q_deg )

#robot.release()