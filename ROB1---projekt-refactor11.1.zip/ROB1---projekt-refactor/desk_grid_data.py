from pathlib import Path

import cv2 as cv
import numpy as np
from ctu_crs import CRS97

from hardware_control import capture_grid, init_robot
from hardware_control.robot.rotations import euler2mat
from utils.tray import TRAY_ID2_CENTER, get_tray_dict
from utils.offsets import patch_target2base
from vision import ArucoPoseSolver, get_marker_pose

z_angles = [np.pi/2, 3*np.pi/2]
id0 = 7
id1 = id0 + 1
tray_imgs_dir = Path(f"./datasets/deska_{id0}_{id1}")

cam_param_dir = Path("./calibration_data/cam_params2/")
K = np.load(cam_param_dir / "K.npy")
dist = np.load(cam_param_dir / "dist.npy")
c2b = np.load("./calibration_data/handeye_output_refined/cam2base.npy")
dh_off = np.load("./calibration_data/handeye_output_refined/dh_offset.npy")
robot = init_robot(CRS97, home=False)
robot.dh_offset = dh_off
robot.gripper.control_position(100)

for imgfile in tray_imgs_dir.glob("*"):
    img = cv.imread(str(imgfile))
    solver = ArucoPoseSolver(get_tray_dict(id0, id1), K, dist)
    t2c = get_marker_pose(img, solver)
    transform = patch_target2base(c2b @ t2c)
    z_off = 0.045
    corn1 = np.array([0,0,z_off])
    corn2 = np.array([*TRAY_ID2_CENTER, z_off])
    for angle in z_angles:
        capture_grid(
            corn1,
            corn2,
            robot,
            grid_shape=(3, 2),
            pose=euler2mat([(np.pi, "y")]),
            z_axis_rotations=[angle],
            transform=transform,
            
        )
