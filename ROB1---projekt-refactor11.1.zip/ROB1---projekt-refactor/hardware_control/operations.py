import time
from pathlib import Path
from typing import Literal

import numpy as np
from ctu_crs.crs_robot import CRSRobot

from .io import save_image_conf
from .robot.move import move_closest_ik
from .robot.move import move_rotated_ik
from .robot.rotations import euler2mat
from utils.offsets import get_skew_axis


GRIPPER_VALS = {"grab": -800, "place": 600}
Z_NEAR = 0.08
Z_PLACE = 0.04
MIDPOINT = euler2mat([(np.pi, "y")])
MIDPOINT[:3, 3] = [0.5, 0, 0.3]
TRAY_OFFSET_X =0 # 0.0005
TRAY_OFFSET_Y =0#0.002 #0.006
ROBOT_OFFSET_X = 0#-0.004
ROBOT_OFFSET_Y = 0.015#0
SKEW_AXIS_ANGLES = {"x": [0, np.pi], "y": [np.pi/2, 3*np.pi/2], "0": [i * np.pi/2 for i in range (4)]}
shift = 0.01 #0.013
shift_en = True
rot_en = False

def shift_parse(robot,xyz_offset, targ_to_base, poz, skew_axis):
    #axis = [[0,False],[1,False]]
    axis = [[0,True],[1,True]]
    if skew_axis == 'y':
        #axis[1][1] = True
        axis = [[1,True]]
    elif skew_axis == 'x':
        #axis[0] = [1,True]
        #axis [1][0] = 0
        axis = [[0,True]]

    for i in axis:
        move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)
        if i[1]:
            robot.gripper.control_position(GRIPPER_VALS["grab"])
            time.sleep(0.5)
        for j in [-1,1]:

            poz[i[0], 3] += j * shift
            move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)
            robot.gripper.control_position(300)
            
            if i[1]:
                time.sleep(0.5)
                robot.gripper.control_position(GRIPPER_VALS["grab"])
                time.sleep(0.5)

            poz[i[0], 3] -= j * shift
        
        #move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)

def move(robot, pose, skew_axis: Literal["x", "y", "0"] = "0"):
    move_rotated_ik(robot, pose, SKEW_AXIS_ANGLES[skew_axis])
    # if not move_rotated_ik(robot, pose, [i * np.pi/2 for i in range(1,4,2)]):
    #     move_rotated_ik(robot, pose, [i * np.pi/2 for i in range(0,4, 2)])

def move_cubes(
    robot: CRSRobot,
    camera,
    targ1_to_base_function,
    targ2_to_base_function,
    cube_data1: np.ndarray,
    cube_data2: np.ndarray,

):
    for i in range(len(cube_data1)):

        #if i<3:
        #    continue                                                    ###############

        if i:
            q = robot.get_q()
            q[0] += np.pi / 6
            robot.move_to_q(q)
            robot.wait_for_motion_stop()
        image = camera.grab_image()
        targ1_to_base = targ1_to_base_function(image)
        targ2_to_base = targ2_to_base_function(image)
        skew_from = get_skew_axis(targ1_to_base)
        grab_cube(robot, targ1_to_base, cube_data1[i], "grab", skew_from)
        move(robot, MIDPOINT)
        skew_to = get_skew_axis(targ2_to_base)
        #if skew_to == "0":
        #    skew_to = skew_from
        grab_cube(robot, targ2_to_base, cube_data2[i], "place", skew_to)
        move(robot, MIDPOINT)


def grab_cube(
    robot: CRSRobot,
    targ_to_base: np.ndarray,
    cube: list,
    mode: Literal["grab", "place"],
    skew_axis: str
):
    poz = euler2mat([(np.pi, "y")])

    poz[0, 3] = cube[0] / 1000 - TRAY_OFFSET_X
    poz[1, 3] = cube[1] / 1000 - TRAY_OFFSET_Y
    # poz[1, 3] *= 1.09
    poz[2, 3] = Z_PLACE
    
    xyz_offset = np.eye(4)
    xyz_offset[:2, 3] = np.array([ROBOT_OFFSET_X, ROBOT_OFFSET_Y])
    xyz_offset[2, 3] = Z_NEAR-Z_PLACE
    move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)
    xyz_offset[2, 3] = 0

    #poz[2, 3] = Z_PLACE
    move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)
    if (mode == "place") and (shift_en):
        shift_parse(robot,xyz_offset, targ_to_base, poz, skew_axis)
    if robot is not None:
        robot.gripper.control_position(GRIPPER_VALS[mode])
        time.sleep(1.5)
    xyz_offset[2, 3] = Z_NEAR-Z_PLACE
    move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)
    if (mode == "place") and (rot_en):
        switch_dict = {"x": "y", "y": "x", "0": "y"}
        move(robot, xyz_offset @ targ_to_base @ poz, switch_dict[skew_axis])
        xyz_offset[2, 3] = 0
        move(robot, xyz_offset @ targ_to_base @ poz, switch_dict[skew_axis])
        robot.gripper.control_position(GRIPPER_VALS["grab"])
        time.sleep(1.5)
        if shift_en:
            shift_parse(robot,xyz_offset, targ_to_base, poz, switch_dict[skew_axis])
        robot.gripper.control_position(GRIPPER_VALS["place"])
        time.sleep(1.5)
        xyz_offset[2, 3] = Z_NEAR-Z_PLACE
        move(robot, xyz_offset @ targ_to_base @ poz, switch_dict[skew_axis])

        move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)
        xyz_offset[2, 3] = 0
        move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)
        robot.gripper.control_position(GRIPPER_VALS["grab"])
        time.sleep(1.5)
        if shift_en:
            shift_parse(robot,xyz_offset, targ_to_base, poz, skew_axis)
        robot.gripper.control_position(GRIPPER_VALS["place"])
        time.sleep(1.5)
        xyz_offset[2, 3] = Z_NEAR-Z_PLACE
        move(robot, xyz_offset @ targ_to_base @ poz, skew_axis)

        


def capture_grid(
    corn1: np.ndarray,
    corn2: np.ndarray,
    robot: CRSRobot,
    grid_shape=(5, 4),
    pose: np.ndarray | None = None,
    euler_rot: list[tuple[float, str]] | None = None,
    z_axis_rotations: list[float] | None = None,
    transform: np.ndarray | None = None,
    camera=None,
    output_dir="./datasets/handeye_data/",
):
    if z_axis_rotations is None:
        z_axis_rotations = [0]

    if pose is None:
        if euler_rot is None:
            e = "Arguments euler_rot and pose cannot both be None"
            raise RuntimeError(e)
        pose = np.eye(4)
        pose[:3, :3] = euler2mat(euler_rot)

    if transform is None:
        transform = np.eye(4)

    pose[2, 3] = corn1[2]
    x1, y1 = corn1[:2]
    x2, y2 = corn2[:2]
    nx, ny = grid_shape
    Path(output_dir).mkdir(exist_ok=True)

    for x in np.linspace(x1, x2, nx):
        for y in np.linspace(y1, y2, ny):
            pose[:2, 3] = np.array([x, y])
            try:
                move_rotated_ik(robot, transform @ pose, z_axis_rotations)
                save_image_conf(robot, camera, dir=output_dir)
            except Exception as e:
                print(e)
                print("orientation IK failed:")
                print(pose)
